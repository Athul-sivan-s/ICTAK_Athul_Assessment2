package com.tech.constants;

public class AutomationConstants {
	
	public static int EXPLICIT_WAIT=10;
	public static String ExpTitle=":: ICT ACADEMY OF KERALA ::";
	public static String ExpSpanValue="Employees";
	public static String ExpAddSpanValue="Add";

}
